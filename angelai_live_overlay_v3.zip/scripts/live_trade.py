#!/usr/bin/env python3
import argparse, asyncio
from api.app.live.engine import LiveConfig, LiveTrader

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["paper","testnet","live"], default="paper")
    p.add_argument("--venue", default="binance")
    p.add_argument("--symbol", default="BTC/USDT")
    p.add_argument("--tf", default="1m")
    args = p.parse_args()
    cfg = LiveConfig(mode=args.mode, venue=args.venue, symbol=args.symbol, tf=args.tf)
    trader = LiveTrader(cfg)
    asyncio.get_event_loop().run_until_complete(trader.run())

if __name__ == "__main__":
    main()
