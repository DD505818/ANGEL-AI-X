# ANGEL.AI — Live Trading Engine (Paper • Testnet • Live)

This overlay adds a **fully functional live trading engine** with three modes:
- **paper** (local broker sim)
- **testnet** (e.g., Binance futures testnet)
- **live** (real keys, use at your own risk)

Core loops included: **data ingestion → features → ensemble signals → risk/sizing → execution → PnL persistence**, with Redis cache, Postgres storage, optional Kafka bus, and Prometheus/OTel hooks.

## Quickstart (paper)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # then edit keys if needed
python scripts/live_trade.py --mode paper --venue binance --symbol BTC/USDT --tf 1m
```

## Testnet (Binance)
Set in `.env`: `BINANCE_TESTNET=true`, add testnet keys, then:
```bash
python scripts/live_trade.py --mode testnet --venue binance --symbol BTC/USDT --tf 1m
```

## Live (real exchanges)
```bash
python scripts/live_trade.py --mode live --venue binance --symbol BTC/USDT --tf 1m
```

> This software is for engineering purposes only and **not investment advice**. Use on live funds at your own risk.
