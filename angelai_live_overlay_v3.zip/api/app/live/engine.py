import os, asyncio, time
import numpy as np, pandas as pd
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv

from api.app.data.exchange import make_exchange
from api.app.signals.ensemble import make_default_ensemble, blend_signals
from api.app.data.ingestor import compute_features
from api.app.exec.paper_broker import PaperBroker

load_dotenv()

@dataclass
class LiveConfig:
    mode: str = "paper"  # paper | testnet | live
    venue: str = "binance"
    symbol: str = "BTC/USDT"
    tf: str = "1m"
    qty: float = 0.01
    slippage_bp_budget: float = float(os.getenv("SLIPPAGE_BP_BUDGET", "8.0"))
    base_fraction: float = float(os.getenv("BASE_FRACTION","0.01"))
    max_fraction: float = float(os.getenv("MAX_FRACTION","0.03"))
    atr_target: float = float(os.getenv("ATR_TARGET","0.015"))
    daily_loss_limit: float = float(os.getenv("DAILY_LOSS_LIMIT","-0.04"))

class LiveTrader:
    def __init__(self, cfg: LiveConfig):
        self.cfg = cfg
        self.ens = make_default_ensemble()
        self.ex = None if cfg.mode=="paper" else make_exchange(cfg.venue)
        self.paper = PaperBroker(slippage_bp_budget=cfg.slippage_bp_budget) if cfg.mode=="paper" else None
        self.nav0 = 100000.0; self.nav = self.nav0
        self.pos = 0.0; self.entry = 0.0

    async def fetch_recent(self, limit:int=500) -> pd.DataFrame:
        # REST polling for simplicity; ccxtpro WS can replace this
        ex = self.ex or make_exchange(self.cfg.venue)
        data = ex.fetch_ohlcv(self.cfg.symbol, timeframe=self.cfg.tf, limit=limit)
        df = pd.DataFrame(data, columns=["ts","open","high","low","close","volume"])
        df["ts"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
        df["venue"]=self.cfg.venue; df["symbol"]=self.cfg.symbol; df["tf"]=self.cfg.tf
        feats = await compute_features(df)
        return feats

    async def step(self):
        df = await self.fetch_recent(limit=600)
        px = df["close"].to_numpy()
        vol_z = df["vol_z20"].to_numpy()
        spread_bp = df.get("spread_bp", pd.Series(5.0, index=df.index)).to_numpy()
        ob_imb = np.clip(vol_z/3 + 0.5, 0, 1)
        queue_depl = np.clip((df["rv_1h"].to_numpy()*50), 0, 1)
        vol_q = (df["rv_1h"].rank(pct=True)).to_numpy()
        spread_q = (pd.Series(spread_bp).rank(pct=True)).to_numpy()
        liq = df.get("liq_usd", pd.Series(1e6, index=df.index)).to_numpy()
        long, exit = blend_signals(px, vol_z, spread_bp, ob_imb, queue_depl, vol_q, spread_q, liq, self.ens)
        # last bar decision
        want_long = bool(long[-1]); want_exit = bool(exit[-1])
        last_px = float(px[-1])
        # risk sizing (ATR proxy)
        atrp = float(pd.Series(px).rolling(14).std().fillna(0.0).iloc[-1])
        frac = min(self.cfg.base_fraction * max(0.25, self.cfg.atr_target / max(atrp/last_px, 1e-9)), self.cfg.max_fraction)
        qty = max(0.0, self.nav * frac / last_px)
        # daily loss guard
        if (self.nav - self.nav0)/self.nav0 < self.cfg.daily_loss_limit:
            return {"action":"halt","reason":"daily_loss_limit","nav":self.nav}
        # act
        if want_long and self.pos<=0:
            res = await self._order("buy", qty, last_px)
            self.pos += qty; self.entry = res["avg_px"]
            return {"action":"buy","qty":qty,"px":res["avg_px"],"nav":self.nav}
        if want_exit and self.pos>0:
            res = await self._order("sell", self.pos, last_px)
            self.nav *= (1.0 + (res["avg_px"]-self.entry)/self.entry)
            self.pos = 0.0
            return {"action":"sell","qty":res["fills"][0][1],"px":res["avg_px"],"nav":self.nav}
        return {"action":"hold","nav":self.nav}

    async def _order(self, side:str, qty:float, px:float):
        if self.cfg.mode=="paper":
            return self.paper.order(self.cfg.symbol, side, qty, px)
        # live/testnet via ccxt
        params = {"type":"limit","timeInForce":"IOC"}  # can switch to postOnly
        o = self.ex.create_order(self.cfg.symbol, "limit", side, qty, px, params)
        # simulate immediate fill summary
        fills = [(px, qty)]
        return {"fills":fills, "avg_px": px}

    async def run(self):
        while True:
            try:
                rep = await self.step()
                print(rep)
            except Exception as e:
                print({"error": str(e)})
            await asyncio.sleep(5)  # 5s step
