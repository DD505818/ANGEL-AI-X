import os, ccxt
from dataclasses import dataclass

@dataclass
class Keys:
    key: str | None = None
    secret: str | None = None
    password: str | None = None

def make_binance(testnet: bool, keys: Keys|None):
    params = { "enableRateLimit": True, "timeout": 20000 }
    if testnet:
        params.update({"options":{"defaultType":"future"}, "urls": {"api": {"fapiPublic":"https://testnet.binancefuture.com/fapi/v1","fapiPrivate":"https://testnet.binancefuture.com/fapi/v1"}}})
    if keys and keys.key:
        params.update({"apiKey": keys.key, "secret": keys.secret})
    return ccxt.binance(params)

def make_exchange(venue: str):
    venue = venue.lower()
    if venue == "binance":
        testnet = os.getenv("BINANCE_TESTNET","false").lower() == "true"
        return make_binance(testnet, Keys(os.getenv("BINANCE_API_KEY"), os.getenv("BINANCE_API_SECRET"), None))
    if venue == "kraken":
        return ccxt.kraken({ "apiKey": os.getenv("KRAKEN_API_KEY"), "secret": os.getenv("KRAKEN_API_SECRET"), "enableRateLimit": True})
    if venue == "coinbase":
        return ccxt.coinbase({ "apiKey": os.getenv("COINBASE_API_KEY"), "secret": os.getenv("COINBASE_API_SECRET"), "password": os.getenv("COINBASE_API_PASSPHRASE"), "enableRateLimit": True})
    raise ValueError(f"Unsupported venue: {venue}")
