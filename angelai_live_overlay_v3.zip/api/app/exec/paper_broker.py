from dataclasses import dataclass
from typing import List, Tuple, Dict, Any
import time, random

@dataclass
class PaperState:
    nav: float = 100000.0
    pos: float = 0.0
    entry: float = 0.0

class PaperBroker:
    def __init__(self, slippage_bp_budget: float=8.0):
        self.s = PaperState()
        self.slip = slippage_bp_budget
        self.trades: List[Dict[str,Any]] = []
    def quote_fill(self, side: str, qty: float, px: float) -> Tuple[float, float]:
        slip = (random.uniform(0, self.slip)/1e4) * (1 if side.lower()=="buy" else -1)
        fill_px = px * (1.0 + slip)
        return fill_px, qty
    def order(self, symbol: str, side: str, qty: float, px: float):
        fill_px, fill_qty = self.quote_fill(side, qty, px)
        if side.lower()=="buy":
            self.s.pos += fill_qty; self.s.entry = fill_px
        else:
            self.s.pos -= fill_qty
        self.trades.append({"symbol":symbol,"side":side,"qty":fill_qty,"price":fill_px,"ts":time.time()})
        return {"fills":[(fill_px, fill_qty)], "avg_px": fill_px}
