# Event Bus (Kafka) — Topics (Optional)

- `ticks.<venue>.<symbol>` — raw trades/ticks (JSON)
- `candles.<venue>.<symbol>.<tf>` — OHLCV bars
- `features.<venue>.<symbol>.<tf>` — computed features
- `signals.<venue>.<symbol>` — ensemble outputs (long/exit/weights)
- `orders` — submitted orders
- `fills` — execution reports
- `pnl` — NAV updates
