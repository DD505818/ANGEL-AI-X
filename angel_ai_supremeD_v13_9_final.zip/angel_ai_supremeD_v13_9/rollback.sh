#!/usr/bin/env bash
set -euo pipefail
angelctl revert --last
