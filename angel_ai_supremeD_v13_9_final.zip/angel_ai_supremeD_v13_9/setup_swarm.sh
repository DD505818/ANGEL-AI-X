#!/usr/bin/env bash
set -euo pipefail
angelctl set agents 0b11111
angelctl set consensus_threshold 3
