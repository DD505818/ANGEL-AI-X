import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    container: { center: true, padding: "2rem" },
    extend: {
      colors: {
        brand: {
          DEFAULT: "#00E0FF",
          glow: "#7DF9FF"
        }
      },
      boxShadow: {
        soft: "0 8px 30px rgba(0,0,0,0.2)"
      }
    }
  },
  plugins: [],
} satisfies Config;
