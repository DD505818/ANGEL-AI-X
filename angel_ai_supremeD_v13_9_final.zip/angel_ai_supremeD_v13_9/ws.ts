import { useEffect } from "react";
import { useApp } from "./store";

export function useLiveWebSocket(url: string) {
  const setConnection = useApp(s => s.setConnection);
  useEffect(() => {
    setConnection("connecting");
    const ws = new WebSocket(url);
    ws.onopen = () => setConnection("connected");
    ws.onclose = () => setConnection("disconnected");
    ws.onerror = () => setConnection("disconnected");
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        // Expected messages: {type: "pnl", id, pnl} | {type: "trade", ...} etc.
        // This is a stub to be wired to your backend.
        // console.log("WS", msg);
      } catch {}
    };
    return () => ws.close();
  }, [url, setConnection]);
}
