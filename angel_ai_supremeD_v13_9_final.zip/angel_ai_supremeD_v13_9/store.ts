import { create } from "zustand";

type Agent = {
  id: string;
  name: string;
  status: "idle" | "running" | "paused" | "error";
  pnl: number;
  sharpe: number;
  trades: number;
};

type State = {
  agents: Agent[];
  toggleAgent: (id: string) => void;
  setAgentStat: (id: string, patch: Partial<Agent>) => void;
  connection: "connected" | "disconnected" | "connecting";
  setConnection: (c: State["connection"]) => void;
};

export const useApp = create<State>((set) => ({
  agents: [
    { id: "qbx", name: "QuantumBoostX", status: "idle", pnl: 0, sharpe: 1.2, trades: 0 },
    { id: "vhawk", name: "VolatilityHawk", status: "idle", pnl: 0, sharpe: 1.4, trades: 0 },
    { id: "fs1m", name: "FlashScalper-1m", status: "idle", pnl: 0, sharpe: 0.9, trades: 0 },
    { id: "mr-vwap", name: "MeanRevert-VWAP", status: "idle", pnl: 0, sharpe: 1.1, trades: 0 }
  ],
  toggleAgent: (id) => set((s) => ({
    agents: s.agents.map(a => a.id === id ? ({...a, status: a.status === "running" ? "paused" : "running"}) : a)
  })),
  setAgentStat: (id, patch) => set((s) => ({
    agents: s.agents.map(a => a.id === id ? ({...a, ...patch}) : a)
  })),
  connection: "disconnected",
  setConnection: (c) => set({connection: c}),
}));
