import numpy as np
def cvar95(x: np.ndarray) -> float:
    if len(x)==0: return 0.0
    q = np.quantile(x, 0.05)
    tail = x[x<=q]
    return float(-tail.mean()) if len(tail)>0 else 0.0
def atr_garch_scale(atr_series: np.ndarray, price: np.ndarray, garch_proxy_series: np.ndarray,
                    atr_target: float=0.015, garch_floor: float=1e-6) -> np.ndarray:
    norm = (atr_series / np.maximum(price, 1e-9))
    scale_atr = np.clip(atr_target / np.maximum(norm, 1e-9), 0.25, 4.0)
    scale_g = np.clip(0.8/np.sqrt(np.maximum(garch_proxy_series, garch_floor)), 0.25, 4.0)
    return scale_atr * scale_g
