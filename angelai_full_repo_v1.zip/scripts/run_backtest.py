#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from api.app.quantum.backtester_weighted import WeightedBacktestEngine, DefaultConfigs
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ohlcv", default=None)
    p.add_argument("--sentiment", default=None)
    p.add_argument("--trials", type=int, default=8)
    args = p.parse_args()
    cfg = DefaultConfigs()
    cfg["run"].trials = int(args.trials)
    eng = WeightedBacktestEngine(symbol="BTC/USDT", csv_ohlcv_path=args.ohlcv, csv_sentiment_path=args.sentiment, **cfg)
    report = eng.run_full()
    outdir = Path(eng.outdir); outdir.mkdir(parents=True, exist_ok=True)
    (outdir/"report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
if __name__ == "__main__":
    main()
