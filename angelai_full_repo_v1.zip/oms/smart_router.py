from dataclasses import dataclass
from typing import Dict
@dataclass
class VenueScore:
    latency_ms: float
    fill_rate: float
    slippage_bp: float
    reliability: float
def pick_venue(scores: Dict[str, VenueScore], prefer_maker: bool=False) -> str:
    best = None; best_s = -1e9
    for name, s in scores.items():
        score = (0.35*(1.0/max(s.latency_ms,1e-3)) +
                 0.30*s.fill_rate -
                 0.20*(s.slippage_bp/100.0) +
                 0.15*s.reliability)
        if prefer_maker: score += 0.05
        if score > best_s: best_s, best = score, name
    return best or next(iter(scores.keys()))
