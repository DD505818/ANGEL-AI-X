from prometheus_client import Counter, Gauge, Histogram
TRADES_TOTAL = Counter("trades_total", "Total trades executed")
WINS_TOTAL   = Counter("trades_won_total", "Total winning trades")
SLIPPAGE_BP  = Histogram("slippage_bp", "Observed slippage in basis points")
FILL_RATE    = Gauge("fill_rate", "Recent venue fill rate")
EQUITY       = Gauge("equity_nav", "Portfolio NAV (normalized)")
DRAWDOWN     = Gauge("portfolio_drawdown", "Current drawdown (0-1)")
TICK_TO_TRADE_MS = Histogram("tick_to_trade_ms", "End-to-end latency")
