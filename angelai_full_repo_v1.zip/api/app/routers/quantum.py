from fastapi import APIRouter, Query
from pathlib import Path
from typing import Optional
from api.app.quantum.backtester_weighted import WeightedBacktestEngine, DefaultConfigs

router = APIRouter()

@router.get("/backtest")
def run_backtest(ohlcv: Optional[str] = Query(default=None),
                 sentiment: Optional[str] = Query(default=None),
                 trials: int = Query(default=8, ge=1, le=200)):
    cfg = DefaultConfigs()
    cfg["run"].trials = trials
    eng = WeightedBacktestEngine(symbol="BTC/USDT", csv_ohlcv_path=ohlcv,
                                 csv_sentiment_path=sentiment, **cfg)
    report = eng.run_full()
    # write alongside
    outdir = Path(eng.outdir); outdir.mkdir(parents=True, exist_ok=True)
    (outdir/"report.json").write_text(__import__("json").dumps(report, indent=2))
    return report
