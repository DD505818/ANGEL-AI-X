from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional
import numpy as np, pandas as pd, optuna, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .indicators import garch_proxy, atr
from .strategies import (
    QBX3Config, SSv2Config, ATRTrendArbConfig, MomentumStacker7Config,
    quantumboost_x3, sentimentsurge_v2, atr_trend_arb, momentum_stacker_7
)

@dataclass
class FeesConfig:
    slippage_bp: float = 1.0  # basis points

@dataclass
class VenueCosts:
    maker_fee: float = 0.0002
    taker_fee: float = 0.0005

@dataclass
class SizingParams:
    base_fraction: float = 0.01
    atr_target: float = 0.015
    garch_window: int = 200
    cvar_budget: float = 0.06
    max_fraction: float = 0.03

@dataclass
class DynamicThresholdsConfig:
    weight_lookback: int = 720
    min_weight: float = 0.05
    corr_penalty: float = 0.25
    sharpe_floor: float = 0.2

@dataclass
class RunConfig:
    trials: int = 8
    seed: int = 42

def DefaultConfigs():
    return dict(
        fees=FeesConfig(),
        venue_costs={v: VenueCosts() for v in ["binance","bybit","coinbase","kraken"]},
        sizing=SizingParams(),
        dyn=DynamicThresholdsConfig(),
        run=RunConfig(),
    )

@dataclass
class Result:
    equity_curve: np.ndarray
    drawdown: np.ndarray
    trades: int
    wins: int
    wr: float
    sharpe: float
    max_dd: float
    pnl: float

class WeightedBacktestEngine:
    def __init__(self, symbol: str, csv_ohlcv_path: Optional[str], csv_sentiment_path: Optional[str],
                 fees: FeesConfig, venue_costs: Dict[str, VenueCosts],
                 sizing: SizingParams, dyn: DynamicThresholdsConfig, run: RunConfig, seed: Optional[int]=None,
                 outdir: Optional[Path]=None) -> None:
        self.symbol = symbol
        self.csv = csv_ohlcv_path
        self.csv_sent = csv_sentiment_path
        self.fees = fees
        self.venues = venue_costs
        self.sizing = sizing
        self.dyn = dyn
        self.run = run
        self.seed = seed or run.seed
        self.outdir = outdir or Path(f"out-weighted/{self.seed}")

    # data
    def load_data(self) -> pd.DataFrame:
        if self.csv:
            df = pd.read_csv(self.csv)
            df = df.rename(columns={c: c.lower() for c in df.columns})
        else:
            n = 6000
            t = np.arange(n)
            rng = np.random.default_rng(self.seed)
            close = 100 + np.sin(t/51.0) * 2.5 + rng.normal(0, 0.6, size=n)
            high = close + 0.6
            low  = close - 0.6
            volume = 1e5 + rng.normal(0, 2.2e4, size=n)
            df = pd.DataFrame(dict(ts=t, open=close, high=high, low=low, close=close, volume=volume))
        if self.csv_sent and Path(self.csv_sent).exists():
            s = pd.read_csv(self.csv_sent)
            s = s.rename(columns={c: c.lower() for c in s.columns})
            df["sentiment"] = s.get("sentiment", pd.Series(0.0, index=df.index)).fillna(0.0)
        else:
            df["sentiment"] = 0.6 + 0.1 * np.tanh(np.sin(np.arange(len(df))/300.0))
        return df

    # helpers
    def _rolling_sharpe(self, x: np.ndarray, w:int) -> np.ndarray:
        import pandas as pd
        s = pd.Series(x)
        mu = s.rolling(w, min_periods=1).mean()
        sd = s.rolling(w, min_periods=1).std().fillna(0.0)
        return np.where(sd>0, (mu/(sd+1e-9))*np.sqrt(252*24*12), 0.0)

    def _cvar95(self, ret: np.ndarray) -> float:
        if len(ret)==0: return 0.0
        q = np.quantile(ret, 0.05)
        tail = ret[ret<=q]
        return float(-tail.mean()) if len(tail)>0 else 0.0

    def _tx_cost(self, venue: str, taker: bool=True) -> float:
        c = self.venues.get(venue, VenueCosts())
        return (c.taker_fee if taker else c.maker_fee) + self.fees.slippage_bp/1e4

    # core simulation
    def simulate_weighted(self, df: pd.DataFrame, params: Dict[str, Any]) -> Result:
        px = df["close"].to_numpy()
        hi = df["high"].to_numpy()
        lo = df["low"].to_numpy()
        vol = np.maximum(1.0, df["volume"].to_numpy())
        sent= df["sentiment"].to_numpy()
        ret = np.diff(px, prepend=px[0])/px
        sigma = garch_proxy(ret, self.sizing.garch_window)
        a = atr(hi, lo, px)

        e1,x1,tp1,sl1 = quantumboost_x3(px, vol, sent, params["qbx3"])
        e2,x2,tp2,sl2 = sentimentsurge_v2(px, vol, sent, params["ssv2"])
        e3,x3,tp3,sl3 = atr_trend_arb(px, hi, lo, params["atra"])
        e4,x4,tp4,sl4 = momentum_stacker_7(px, params["ms7"])
        masks = [e1,e2,e3,e4]; exits=[x1,x2,x3,x4]; tps=[tp1,tp2,tp3,tp4]; sls=[sl1,sl2,sl3,sl4]

        strat_ret = []
        for en,ex,tp,sl in zip(masks,exits,tps,sls):
            r = np.where(en, np.clip(ret, -sl, tp), 0.0)
            r = np.where(ex, 0.0, r)
            strat_ret.append(r)
        strat_ret = np.vstack(strat_ret)

        look = self.dyn.weight_lookback
        scores = np.zeros_like(strat_ret)
        for s in range(strat_ret.shape[0]):
            scores[s] = self._rolling_sharpe(strat_ret[s], look)

        W = np.zeros_like(scores)
        for t in range(strat_ret.shape[1]):
            window = max(10, min(t, look))
            R = strat_ret[:, max(0,t-window):t+1]
            if R.shape[1] < 10:
                raw = np.ones((strat_ret.shape[0],))
            else:
                corr = np.corrcoef(R)
                pen = 1.0/(1.0 + np.mean(np.abs(corr - np.eye(len(corr))), axis=1))
                raw = scores[:,t] * ( (1.0-self.dyn.corr_penalty) + self.dyn.corr_penalty*pen )
            raw = np.clip(raw, 0.0, None) + self.dyn.min_weight
            w = raw/raw.sum() if raw.sum()>0 else np.full_like(raw, 1.0/len(raw))
            W[:,t] = w

        # ATR×GARCH scaling + CVaR budget
        target = self.sizing.atr_target
        vol_scale = np.clip(target / (np.maximum(1e-9, a/px)), 0.25, 4.0) * np.clip(0.8/np.sqrt(np.maximum(1e-9, sigma)), 0.25, 4.0)
        frac_base = np.clip(self.sizing.base_fraction * vol_scale, 0.0, self.sizing.max_fraction)

        equity = np.ones_like(px, dtype=float)
        per_step_ret = np.zeros_like(px, dtype=float)
        trades=wins=0
        for t in range(1, len(px)):
            alloc = frac_base[t] * W[:,t]
            r_mix = float(np.dot(alloc, strat_ret[:,t]))
            if (strat_ret[:,t]!=0).any():
                r_mix -= self.fees.slippage_bp/1e4
                trades += 1; wins += 1 if r_mix>0 else 0
            per_step_ret[t] = r_mix
            trail = per_step_ret[max(0,t-look):t+1]
            cvar = self._cvar95(trail)
            if cvar > self.sizing.cvar_budget:
                scale = max(0.25, self.sizing.cvar_budget / (cvar+1e-9))
                r_mix *= scale; per_step_ret[t] = r_mix
            equity[t] = equity[t-1] * (1.0 + r_mix)

        dd = 1.0 - equity/np.maximum.accumulate(equity)
        wr = wins/max(1,trades)
        pnl = equity[-1]-1.0
        sharpe = float(np.mean(per_step_ret)/(np.std(per_step_ret)+1e-9)*np.sqrt(252*24*12))
        return Result(equity, dd, trades, wins, wr, sharpe, float(dd.max()), pnl)

    def _objective(self, trial: optuna.Trial, df: pd.DataFrame) -> float:
        params = {
            "qbx3": QBX3Config(
                rsi_buy_low=trial.suggest_float("qbx3_rsi_low", 20, 40),
                rsi_sell_high=trial.suggest_float("qbx3_rsi_high", 60, 80),
                sentiment_buy=trial.suggest_float("qbx3_sent", 0.6, 0.85),
                tp_pct=trial.suggest_float("qbx3_tp", 0.01, 0.03),
                sl_pct=trial.suggest_float("qbx3_sl", 0.005, 0.02),
            ),
            "ssv2": SSv2Config(
                sentiment_buy=trial.suggest_float("ssv2_sent", 0.7, 0.9),
                tp_pct=trial.suggest_float("ssv2_tp", 0.01, 0.03),
                sl_pct=trial.suggest_float("ssv2_sl", 0.005, 0.02),
            ),
            "atra": ATRTrendArbConfig(
                bb_n=trial.suggest_int("atra_n", 18, 22),
                bb_k=trial.suggest_float("atra_k", 1.8, 2.2),
                atr_delta=trial.suggest_float("atra_delta", 0.05, 0.2),
                tp_pct=trial.suggest_float("atra_tp", 0.01, 0.03),
                sl_pct=trial.suggest_float("atra_sl", 0.005, 0.02),
            ),
            "ms7": MomentumStacker7Config(
                mom_thresh=trial.suggest_float("ms7_mom", 0.005, 0.02),
                rsi_low=trial.suggest_float("ms7_rsi_low", 35, 45),
                rsi_high=trial.suggest_float("ms7_rsi_high", 55, 65),
                tp_pct=trial.suggest_float("ms7_tp", 0.01, 0.03),
                sl_pct=trial.suggest_float("ms7_sl", 0.005, 0.02),
            ),
        }
        res = self.simulate_weighted(df, params)
        return float(res.equity_curve[-1] - 0.75*res.max_dd)

    def _save_outputs(self, df: pd.DataFrame, res: Result) -> None:
        out = self.outdir
        out.mkdir(parents=True, exist_ok=True)
        pd.DataFrame({"equity": res.equity_curve, "drawdown": res.drawdown}).to_csv(out / "metrics.csv", index=False)
        plt.figure(figsize=(10,4)); plt.plot(res.equity_curve); plt.title("Equity (weighted)"); plt.tight_layout(); plt.savefig(out/"equity_curve.png"); plt.close()
        plt.figure(figsize=(10,3)); plt.plot(res.drawdown); plt.title("Drawdown"); plt.tight_layout(); plt.savefig(out/"drawdown.png"); plt.close()

    def run_full(self) -> Dict[str, Any]:
        df = self.load_data()
        optuna.logging.set_verbosity(optuna.logging.WARNING)
        study = optuna.create_study(direction="maximize")
        study.optimize(lambda tr: self._objective(tr, df), n_trials=self.run.trials)
        best = study.best_params
        res = self.simulate_weighted(df, {
            "qbx3": QBX3Config(best["qbx3_rsi_low"], best["qbx3_rsi_high"], best["qbx3_sent"], best["qbx3_tp"], best["qbx3_sl"]),
            "ssv2": SSv2Config(best["ssv2_sent"], best["ssv2_tp"], best["ssv2_sl"]),
            "atra": ATRTrendArbConfig(best["atra_n"], best["atra_k"], best["atra_delta"], best["atra_tp"], best["atra_sl"]),
            "ms7": MomentumStacker7Config(best["ms7_mom"], best["ms7_rsi_low"], best["ms7_rsi_high"], best["ms7_tp"], best["ms7_sl"]),
        })
        self._save_outputs(df, res)
        return {
            "summary": {
                "equity": float(res.equity_curve[-1]),
                "max_dd": float(res.max_dd),
                "wr": float(res.wr),
                "sharpe": float(res.sharpe),
                "trials": self.run.trials,
            },
            "best_params": best,
        }
