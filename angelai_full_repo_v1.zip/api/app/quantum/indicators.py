import numpy as np

def rsi(close: np.ndarray, n:int=14) -> np.ndarray:
    diff = np.diff(close, prepend=close[0])
    up = np.clip(diff, 0, None)
    dn = -np.clip(diff, None, 0)
    ema_up = ema(up, n)
    ema_dn = ema(dn, n)
    rs = np.divide(ema_up, np.maximum(1e-9, ema_dn))
    return 100 - (100 / (1 + rs))

def ema(x: np.ndarray, n:int) -> np.ndarray:
    a = 2/(n+1.0)
    y = np.empty_like(x, dtype=float)
    y[0]=x[0]
    for i in range(1,len(x)):
        y[i] = a*x[i] + (1-a)*y[i-1]
    return y

def macd(close: np.ndarray, n_fast:int=12, n_slow:int=26, n_sig:int=9):
    fast = ema(close, n_fast)
    slow = ema(close, n_slow)
    line = fast - slow
    sig = ema(line, n_sig)
    hist = line - sig
    return line, sig, hist

def zscore(x: np.ndarray, n:int=20) -> np.ndarray:
    import pandas as pd
    s = pd.Series(x)
    m = s.rolling(n, min_periods=1).mean()
    sd = s.rolling(n, min_periods=1).std().fillna(0.0)
    return ((s - m) / (sd + 1e-9)).to_numpy()

def bollinger(close: np.ndarray, n:int=20, k:float=2.0):
    import pandas as pd
    s = pd.Series(close)
    ma = s.rolling(n, min_periods=1).mean()
    sd = s.rolling(n, min_periods=1).std().fillna(0.0)
    up = ma + k*sd
    lo = ma - k*sd
    return ma.to_numpy(), up.to_numpy(), lo.to_numpy()

def atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, n:int=14) -> np.ndarray:
    tr = np.maximum(high - low, np.maximum(np.abs(high - np.roll(close,1)), np.abs(low - np.roll(close,1))))
    tr[0] = high[0]-low[0]
    return ema(tr, n)

def garch_proxy(returns: np.ndarray, n:int=200) -> np.ndarray:
    # Simple rolling variance proxy to approximate volatility clustering
    import pandas as pd
    s = pd.Series(returns)
    v = s.rolling(n, min_periods=1).var().fillna(0.0)
    return v.to_numpy()
