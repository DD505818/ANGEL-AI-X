import logging, os
from typing import AsyncIterator, Callable
import asyncpg
import aioredis
from aioredis import Redis
from fastapi import FastAPI
from prometheus_client import Counter, Histogram, generate_latest
from starlette.requests import Request
from starlette.responses import Response

from .routers.quantum import router as quantum_router

logger = logging.getLogger(__name__)
app = FastAPI(title="ANGEL.AI Backend", version="1.0.0")
app.include_router(quantum_router, prefix="/quantum", tags=["quantum"])

REQUEST_TIME = Histogram("http_request_duration_seconds", "Request latency")
HITS = Counter("http_request_total", "Total HTTP hits")

@app.on_event("startup")
async def startup() -> None:
    pg_url = os.getenv("POSTGRES_URL")
    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    app.state.pg_pool = None
    if pg_url:
        app.state.pg_pool = await asyncpg.create_pool(dsn=pg_url, min_size=1, max_size=10)
    app.state.redis = aioredis.from_url(redis_url, encoding="utf-8", decode_responses=True)

@app.on_event("shutdown")
async def shutdown() -> None:
    if app.state.pg_pool:
        await app.state.pg_pool.close()
    if app.state.redis:
        await app.state.redis.close()

async def get_pg() -> AsyncIterator[asyncpg.Connection]:
    if not app.state.pg_pool:
        raise RuntimeError("Postgres not configured")
    async with app.state.pg_pool.acquire() as conn:
        yield conn

async def get_redis() -> AsyncIterator[Redis]:
    yield app.state.redis

@app.middleware("http")
async def metrics_mw(request: Request, call_next: Callable) -> Response:
    HITS.inc()
    with REQUEST_TIME.time():
        return await call_next(request)

@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}

@app.get("/metrics")
async def metrics() -> Response:
    return Response(generate_latest(), media_type="text/plain")
