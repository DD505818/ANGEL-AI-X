# ANGEL.AI — Full Stack Trading System (Updated Overlay)

This repo overlay ships:
- **Weighted Multi‑Strategy Backtester** with ATR×GARCH scaling + CVaR‑95 budget
- **FastAPI backend** with `/metrics`, `/health`, and `/quantum/backtest` endpoints
- **Indicators & Strategies** (QBX3, SSv2, ATRA, MS7)
- **RMS sizing helpers** and **OMS smart router scaffold**
- **Prometheus + Grafana** dashboards
- **Dockerfile + docker‑compose** for local infra
- **CI workflow** + **tests** (smoke)

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Smoke backtest (weighted engine; synthetic data)
python scripts/run_backtest.py --weighted --trials 8

# Run API
uvicorn api.app.main:app --host 0.0.0.0 --port 8000 --reload
```

Grafana (when using docker-compose): http://localhost:3001  
Prometheus: http://localhost:9090
