import numpy as np
from api.app.quantum.indicators import rsi, macd, zscore, bollinger, atr, garch_proxy
def test_indicators_smoke():
    x = np.linspace(100, 110, 200) + np.random.default_rng(0).normal(0,0.2,200)
    hi = x + 0.5; lo = x - 0.5
    assert rsi(x).shape[0]==200
    m, s, h = macd(x); assert m.shape==s.shape==h.shape
    assert zscore(x).shape[0]==200
    _, up, lo2 = bollinger(x, 20, 2.0); assert up.shape[0]==200
    assert atr(hi, lo, x).shape[0]==200
    ret = np.diff(x, prepend=x[0])/x
    assert garch_proxy(ret, 50).shape[0]==200
