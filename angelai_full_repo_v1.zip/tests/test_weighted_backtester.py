from api.app.quantum.backtester_weighted import WeightedBacktestEngine, DefaultConfigs
def test_weighted_backtester_smoke():
    cfg = DefaultConfigs()
    cfg["run"].trials = 3
    eng = WeightedBacktestEngine(symbol="BTC/USDT", csv_ohlcv_path=None, csv_sentiment_path=None, **cfg)
    rep = eng.run_full()
    assert "summary" in rep and "best_params" in rep
